module.exports.function = function returnCountry (LocalTeamName, VisitorTeamName, Country, League) {
  return {
    "LocalTeamName":LocalTeamName,
    "VisitorTeamName":VisitorTeamName,
    "Country":Country,
    "League": League,
  }
}
